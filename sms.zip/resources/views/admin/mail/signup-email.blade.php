Hello {{ $email_data['name'] }}
<br><br>
Welcome to Peak and Dale
<br>
Please click the below link to verify your email and activate your account.
<br><br>
<a href="http://sms.teddygenial.com/verify?code={{ $email_data['verification_code'] }}">Click Here!</a>
<br><br>
Thank you!

<br>
Peak and Dale Solutions.
