<?php $__env->startSection('content'); ?>
             <!-- HEADER -->
             <div class="header">
                <div class="container-fluid">

                  <!-- Body -->
                  <div class="header-body">
                    <div class="row align-items-end">
                      <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                           SMS Outbox
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                          SMS Outbox
                        </h1>

                      </div>
                      <div class="col-auto">

                        <!-- Button -->
                        

                      </div>
                    </div> <!-- / .row -->
                  </div> <!-- / .header-body -->

                </div>
              </div> <!-- / .header -->
              <div class="container-fluid">
                <div class="card">
                  <div class="card-header">
                    <h2 class="card-title">SMS Outbox</h2>
                  </div>
                  <div class="card-body">
                    <table class="table table-sm">
                      <thead>
                        <th>Date</th>
                        <th>Text</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Cost</th>
                        <th>Link ID</th>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(date('M d, Y, H:i:s', strtotime($message->createdOn))); ?></td>
                            <td><?php echo e($message->message); ?></td>
                            <td><?php echo e($message->name); ?></td>
                            <td><?php echo e($message->to); ?></td>
                            <td>Ksh. 1</td>
                            <td></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tedd/public_html/sms/resources/views/client/outbox/index.blade.php ENDPATH**/ ?>