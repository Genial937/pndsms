<?php $__env->startSection('content'); ?>
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            SMS Templates
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            SMS Templates
                        </h1>

                    </div>
                    <div class="col-auto">


                        <?php if($search !== null): ?>
                        <a href="<?php echo e(route('client-templates.index')); ?>" class="btn btn-primary lift">
                            <i class="fa fa-chevron-left"></i> Back
                        </a>

                        <?php endif; ?>
                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

            <div class="page-body py-4">
                <div class="card">
                    <div class="card-header">
                        Sort by company
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('template.search')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <select name="client" id="" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Sort <i class="fe fe-filter"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            SMS Templates
                        </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <th>Icon</th>
                                <th>Name</th>
                                <th>Body</th>
                                <th>Company</th>
                                
                                
                            </thead>
                            <tbody>
                               <?php if($search === null): ?>
                               <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td>
                                    <?php if($template->icon !== ""): ?>
                                    <a href=""><img src="<?php echo e(asset('icons')); ?>/<?php echo e($template->icon); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                    <?php else: ?>
                                    <a href=""><img src="<?php echo e(asset('img/icon.png')); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($template->template_name); ?></td>
                                <td><?php echo e($template->body); ?></td>
                                <td><?php echo e($template->name); ?></td>
                                
                                
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php else: ?>
                               <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td>
                                    <?php if($template->icon !== ""): ?>
                                    <a href=""><img src="<?php echo e(asset('icons')); ?>/<?php echo e($template->icon); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                    <?php else: ?>
                                    <a href=""><img src="<?php echo e(asset('img/icon.png')); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($template->template_name); ?></td>
                                <td><?php echo e($template->body); ?></td>
                                <td><?php echo e($template->name); ?></td>
                                
                                
                                </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- / .header -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/admin/templates/index.blade.php ENDPATH**/ ?>