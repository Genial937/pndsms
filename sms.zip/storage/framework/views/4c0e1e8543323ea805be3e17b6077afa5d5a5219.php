<?php $__env->startSection('content'); ?>
<div class="header">
    <div class="container-fluid">

        <!-- Body -->
        <div class="header-body">
            <div class="row align-items-end">
                <div class="col">

                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                        Edit SMS Templates
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                        Edit SMS Templates
                    </h1>

                </div>
                <div class="col-auto">


                    <a href="<?php echo e(route('template.index')); ?>" class="btn btn-primary lift">
                        <i class="fa fa-chevron-left"></i> Back
                    </a>

                </div>
            </div> <!-- / .row -->
        </div> <!-- / .header-body -->

        <div class="page-body py-4">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        Edit SMS Templates
                    </h2>
                </div>
                <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <a href="#" data-dismiss="alert" class="close">&times;</a>
                            <p><?php echo e(session('message')); ?></p>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('template.update', $id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="">Template name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="template_name" value="<?php echo e($template->template_name); ?>">
                            <?php $__errorArgs = ['template_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                           <div class="row">
                               <div class="col-md-8">
                                <label for="">Icon <span class="text-danger"></span></label>
                                <input type="file" class="form-control" name="icon">
                               </div>
                               <div class="col-md-4">
                                <?php if($template->icon !== ""): ?>
                                <a href=""><img src="<?php echo e(asset('icons/')); ?>/<?php echo e($template->icon); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                <?php else: ?>
                                <a href=""><img src="<?php echo e(asset('img/icon.png')); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                <?php endif; ?>
                               </div>
                           </div>
                        </div>
                        <div class="form-group">
                            <label for="">Body <span class="text-danger">*</span></label>
                            <textarea name="body" class="form-control" id="" cols="30" rows="5"><?php echo e($template->body); ?></textarea>
                            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="from-group">
                            <button type="submit" class="btn btn-primary pull-right">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <!-- / .header -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/client/templates/show.blade.php ENDPATH**/ ?>