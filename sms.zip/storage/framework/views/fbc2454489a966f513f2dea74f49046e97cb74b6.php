<?php $__env->startSection('content'); ?>
 <div class="header">
   <div class="container-fluid">

     <!-- Body -->
     <div class="header-body">
       <div class="row align-items-end">
         <div class="col">

           <!-- Pretitle -->
           <h6 class="header-pretitle">
              Change Profile
           </h6>

           <!-- Title -->
           <h1 class="header-title">
             Change Profile
           </h1>

         </div>
         <div class="col-auto">

           <!-- Button -->
           <a href="<?php echo e(route('my-profile.index')); ?>" class="btn btn-primary lift">
             <i class="fa fa-chevron-left"></i> Back
           </a>

         </div>
       </div> <!-- / .row -->
     </div> <!-- / .header-body -->

   </div>
 </div> <!-- / .header -->
 <div class="container-fluid">
   <div class="card">
       <div class="card-header">
           Change Profile
       </div>

       <div class="card-body">
        <ul class="nav nav-tabs nav-tabs-solid">
            <li class="nav-item"><a class="nav-link active" href="#solid-tab1" data-toggle="tab">Update User Information</a></li>
            <li class="nav-item"><a class="nav-link" href="#solid-tab2" data-toggle="tab">Change Password</a></li>
        </ul>
        <?php if(session('msg')): ?>
           <div class="alert alert-success">
               <a href="#" data-dismiss="alert" class="close">&times;</a>
               <p><?php echo e(session('msg')); ?></p>
           </div>
       <?php endif; ?>
        <div class="tab-content">
            <div class="tab-pane show active p-4" id="solid-tab1">
                <div class="card">
                    <div class="card-body">
                        <?php if(session('message')): ?>
                            <div class="alert alert-success">
                                <a href="#" data-dismiss="alert" class="close">&times;</a>
                                <p><?php echo e(session('message')); ?></p>
                            </div>
                        <?php endif; ?>
                        <form action="<?php echo e(route('my-profile.update', auth()->user()->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="">Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e(auth()->user()->email); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Primary Contact Phone</label>
                                <input type="text" class="form-control" name="phone" value="<?php echo e(auth()->user()->primary_contact); ?>">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Alternative Contact Phone</label>
                                <input type="text" class="form-control" name="alt_phone" value="<?php echo e(auth()->user()->alt_contact); ?>">
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-8">
                                        <label for="">Profile</label>
                                        <input type="file" class="form-control" name="profile" >
                                    </div>
                                    <div class="col-md-4">
                                        <?php if(auth()->user()->profile !== null): ?>
                                        <a href=""><img src="<?php echo e(asset('img/profiles')); ?>/<?php echo e(auth()->user()->profile); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                        <?php else: ?>
                                        <a href=""><img src="<?php echo e(asset('img/avatars/profiles/avatar-1.jpg')); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary pull-right">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="tab-pane p-4" id="solid-tab2">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('pass.change', auth()->user()->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="">Current Password</label>
                                <input type="password" class="form-control" name="current_password">
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="">New Password</label>
                                <input type="password" class="form-control" name="new_password">
                                <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="">Confirm Password</label>
                                <input type="password" class="form-control" name="password_confirmation">
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary pull-right">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
       </div>
   </div>
  </div>
 </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/client/profile/create.blade.php ENDPATH**/ ?>