<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">

        <!-- Image -->
        

        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body mt-n5 mt-md-n6">
                <div class="row align-items-end">
                    <div class="col-auto">

                        <!-- Avatar -->
                        

                    </div>
                    <div class="col mb-3 ml-n3 ml-md-n2">

                        <!-- Pretitle -->
                        

                        <!-- Title -->
                        

                    </div>
                    <div class="col-12 col-md-auto mt-2 mt-md-0 mb-md-3">

                     <!-- Button -->
                        

                    </div>
                </div> <!-- / .row -->
                <div class="row align-items-center">
                    <div class="col">

                        <a href="<?php echo e(route('my-profile.show', auth()->user()->id)); ?>" class="btn btn-primary d-block d-md-inline-block lift pull-right" style="margin-top: 20px">
                            Change Profile
                     </a>
                    </div>
                </div>
            </div> <!-- / .header-body -->

        </div>
    </div>

    <!-- CONTENT -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-xl-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">User Information</h2>
                    </div>
                    <div class="card-body">
                        <form action="">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="img-thumb">
                                     <?php if(auth()->user()->profile !== null): ?>
                                     <img src="<?php echo e(asset('img/profiles')); ?>/<?php echo e(auth()->user()->profile); ?>" alt="">
                                     <?php else: ?>
                                     <img src="<?php echo e(asset('img/avatars/profiles/avatar-1.jpg')); ?>" alt="">
                                     <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-8">
                                    <!-- List group -->
                                    <div class="list-group list-group-flush my-n3">
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">

                                                    <!-- Title -->
                                                    <h5 class="mb-0">
                                                       Name
                                                    </h5>

                                                </div>
                                                <div class="col-auto">

                                                    <!-- Time -->
                                                    <time class="small text-muted" datetime="1988-10-24">
                                                        <?php echo e(auth()->user()->name); ?>

                                                        
                                                    </time>

                                                </div>
                                            </div> <!-- / .row -->
                                        </div>
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">

                                                    <!-- Title -->
                                                    <h5 class="mb-0">
                                                        Email
                                                    </h5>

                                                </div>
                                                <div class="col-auto">

                                                    <!-- Time -->
                                                    <time class="small text-muted" datetime="2018-10-28">
                                                        <?php echo e(auth()->user()->email); ?>

                                                    </time>

                                                </div>
                                            </div> <!-- / .row -->
                                        </div>
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">

                                                    <!-- Title -->
                                                    <h5 class="mb-0">
                                                        Phone
                                                    </h5>

                                                </div>
                                                <div class="col-auto">

                                                    <!-- Text -->
                                                    <small class="text-muted">
                                                        <?php echo e(auth()->user()->primary_contact); ?>

                                                    </small>

                                                </div>
                                            </div> <!-- / .row -->
                                        </div>
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">

                                                    <!-- Title -->
                                                    <h5 class="mb-0">
                                                       Username
                                                    </h5>

                                                </div>
                                                <div class="col-auto">

                                                    <!-- Link -->
                                                    <a href="#!" class="small">
                                                        <?php echo e(auth()->user()->username); ?>

                                                    </a>

                                                </div>
                                            </div> <!-- / .row -->
                                        </div>
                                        <div class="list-group-item">
                                            <div class="row align-items-center">
                                                <div class="col">

                                                    <!-- Title -->
                                                    <h5 class="mb-0">
                                                       Api Key
                                                    </h5>

                                                </div>
                                                <div class="col-auto">

                                                    <!-- Link -->
                                                    <a href="#!" class="small">
                                                        <?php echo e($token->password); ?>

                                                    </a>

                                                </div>
                                            </div> <!-- / .row -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                
            </div>

        </div> <!-- / .row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/client/profile/index.blade.php ENDPATH**/ ?>