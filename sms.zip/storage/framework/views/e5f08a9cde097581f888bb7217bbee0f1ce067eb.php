<?php $__env->startSection('content'); ?>
<div class="header">
    <div class="container-fluid">

        <!-- Body -->
        <div class="header-body">
            <div class="row align-items-end">
                <div class="col">

                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                        Create SMS Templates
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                        Create SMS Templates
                    </h1>

                </div>
                <div class="col-auto">


                    <a href="<?php echo e(route('template.index')); ?>" class="btn btn-primary lift">
                        <i class="fa fa-chevron-left"></i> Back
                    </a>

                </div>
            </div> <!-- / .row -->
        </div> <!-- / .header-body -->

        <div class="page-body py-4">
            <div class="card">
                <div class="card-header">
                    <h2 class="card-title">
                        Create SMS Templates
                    </h2>
                </div>
                <div class="card-body">
                    <?php if(session('message')): ?>
                        <div class="alert alert-success">
                            <a href="#" data-dismiss="alert" class="close">&times;</a>
                            <p><?php echo e(session('message')); ?></p>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('template.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Template name <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="template_name">
                            <?php $__errorArgs = ['template_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group">
                            <label for="">Icon <span class="text-danger"></span></label>
                            <input type="file" class="form-control" name="icon">
                        </div>
                        <div class="form-group">
                            <label for="">Body <span class="text-danger">*</span></label>
                            <textarea name="body" class="form-control" id="" cols="30" rows="5"></textarea>
                            <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="from-group">
                            <button type="submit" class="btn btn-primary pull-right">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> <!-- / .header -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tedd/public_html/sms/resources/views/client/templates/create.blade.php ENDPATH**/ ?>