<?php $__env->startSection('content'); ?>
             <!-- HEADER -->
             <div class="header">
                <div class="container-fluid">

                  <!-- Body -->
                  <div class="header-body">
                    <div class="row align-items-end">
                      <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                           Client Subscriptions
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                          Client Subscriptions
                        </h1>

                      </div>
                      <div class="col-auto">

                        <!-- Button -->
                       <?php if($search !== null): ?>
                       <a href="<?php echo e(route('subscriptions.index')); ?>" class="btn btn-primary lift">
                        <i class="fa fa-chevron-left"></i> Back
                      </a>
                       <?php endif; ?>

                      </div>
                    </div> <!-- / .row -->
                  </div> <!-- / .header-body -->

                </div>
              </div> <!-- / .header -->
              <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        Sort by company
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('sub.search')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <select name="client" id="" class="form-control" required>
                                            <option value="" disabled selected>Select</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <button class="btn btn-primary">Sort <i class="fe fe-filter"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                  <div class="card-header">
                    <h2 class="card-title">Client Subscriptions</h2>
                  </div>
                  <div class="card-body">
                    <table class="table table-sm">
                      <thead>
                        <th>Transaction ID</th>
                        <th>Transaction Amount</th>
                        <th>Transaction Date</th>
                        <th>SMS Awarded</th>
                        <th>Paid By</th>

                      </thead>
                      <tbody>
                        <?php if($search !== null): ?>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pay->mpesa_receipt); ?></td>
                            <td>KES. <?php echo e(number_format($pay->amount,2)); ?></td>
                            <td><?php echo e(date('M d, Y', strtotime($pay->created_at))); ?></td>
                            <td><?php echo e($pay->amount); ?> SMS</td>
                            <td><?php echo e($pay->name); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pay->mpesa_receipt); ?></td>
                            <td>KES. <?php echo e(number_format($pay->amount,2)); ?></td>
                            <td><?php echo e(date('M d, Y', strtotime($pay->created_at))); ?></td>
                            <td><?php echo e($pay->amount); ?> SMS</td>
                            <td><?php echo e($pay->name); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/admin/subscriptions/index.blade.php ENDPATH**/ ?>