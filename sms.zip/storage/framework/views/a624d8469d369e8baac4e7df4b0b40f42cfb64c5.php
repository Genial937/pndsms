<?php $__env->startSection('content'); ?>
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            SMS Templates
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            SMS Templates
                        </h1>

                    </div>
                    <div class="col-auto">


                        <a href="<?php echo e(route('template.create')); ?>" class="btn btn-primary lift">
                            Add New SMS Template
                        </a>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

            <div class="page-body py-4">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            SMS Templates
                        </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm">
                            <thead>
                                <th>Icon</th>
                                <th>Name</th>
                                <th>Body</th>
                                
                                <th>Created</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                       <?php if($template->icon !== ""): ?>
                                       <a href=""><img src="<?php echo e(asset('icons')); ?>/<?php echo e($template->icon); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                       <?php else: ?>
                                       <a href=""><img src="<?php echo e(asset('img/icon.png')); ?>" alt=""  style="width:70px; height:70px; border-radius:50%"></a>
                                       <?php endif; ?>
                                    </td>
                                    <td><?php echo e($template->template_name); ?></td>
                                    <td><?php echo e($template->body); ?></td>
                                    
                                    <td><?php echo e(date('M d, Y, H:i:s', strtotime($template->created_at))); ?></td>
                                    <td style="display: flex">
                                        <a href="<?php echo e(route('template.show', $template->id)); ?>" class="btn btn-primary btn-sm mr-1"><i class="fa fa-pencil"></i></a>
                                        <form action="<?php echo e(route('template.destroy', $template->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                        </form>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- / .header -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tedd/public_html/sms/resources/views/client/templates/index.blade.php ENDPATH**/ ?>