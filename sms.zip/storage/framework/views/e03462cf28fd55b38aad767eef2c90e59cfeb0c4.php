<?php $__env->startSection('content'); ?>
             <!-- HEADER -->
             <div class="header">
                <div class="container-fluid">

                  <!-- Body -->
                  <div class="header-body">
                    <div class="row align-items-end">
                      <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                           SMS Outbox
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                          SMS Outbox
                        </h1>

                      </div>
                      <div class="col-auto">

                        <!-- Button -->
                        <?php if($search !== null): ?>
                        <a href="<?php echo e(route('client-outbox.index')); ?>" class="btn btn-primary lift">
                           <i class="fa fa-chevron-left"></i> Back
                           </a>
                        <?php endif; ?>

                      </div>
                    </div> <!-- / .row -->
                  </div> <!-- / .header-body -->

                </div>
              </div> <!-- / .header -->
              <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        Sort by company
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('outbox.search')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <select name="client" id="" class="form-control" required>
                                            <option value="" disabled selected>Select</option>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($client->id); ?>"><?php echo e($client->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Sort <i class="fe fe-filter"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="card">
                  <div class="card-header">
                    <h2 class="card-title">SMS Outbox</h2>
                  </div>
                  <div class="card-body">
                    <table class="table table-sm">
                      <thead>
                        <th>Date</th>
                        <th>Text</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Client</th>
                        <th>Cost</th>
                        <th>Sold At</th>
                        <th>Link ID</th>
                      </thead>
                      <tbody>
                      <?php if($search === null): ?>
                      <?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                       <td><?php echo e(date('M d, Y', strtotime($item->createdOn))); ?></td>
                       <td><?php echo e($item->message); ?></td>
                       <td><?php echo e($item->name); ?></td>
                       <td><?php echo e($item->to); ?></td>
                       <td><?php echo e($item->name); ?></td>
                       <td>KES 0.80</td>
                       <td>KES 1</td>
                       <td></td>
                     </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php else: ?>
                      <?php $__currentLoopData = $sms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                       <td><?php echo e(date('M d, Y', strtotime($item->createdOn))); ?></td>
                       <td><?php echo e($item->message); ?></td>
                       <td><?php echo e($item->name); ?></td>
                       <td><?php echo e($item->to); ?></td>
                       <td><?php echo e($item->name); ?></td>
                       <td>KES 0.80</td>
                       <td>KES 1</td>
                       <td></td>
                     </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/admin/outbox/index.blade.php ENDPATH**/ ?>