Hello <?php echo e($email_data['name']); ?>

<br><br>
Welcome to Peak and Dale
<br>
Please click the below link to verify your email and activate your account.
<br><br>
<a href="http://127.0.0.1:8000/verify?code=<?php echo e($email_data['verification_code']); ?>">Click Here!</a>
<br><br>
Thank you!

<br>
Peak and Dale Solutions.
<?php /**PATH C:\xampp\htdocs\sms_system\resources\views/admin/mail/signup-email.blade.php ENDPATH**/ ?>