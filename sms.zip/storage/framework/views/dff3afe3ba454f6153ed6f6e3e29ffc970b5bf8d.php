<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Tags
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            Tags
                        </h1>

                    </div>
                    <div class="col-auto">


                        <a href="<?php echo e(route('tags.create')); ?>" class="btn btn-primary lift">
                            Add Tag
                        </a>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->

    <div class="page-body py-4 container-fluid ">
        <div class="row">
            
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">
                            Tags List
                        </h2>
                    </div>
                    <div class="card-body">
                        <table class="table table-sm table-stripped">
                            <thead>
                                <th>Tag Name</th>
                                <th>Date Created</th>
                                <th>No of Contacts</th>
                                <th>ACtion</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $contacts = App\Models\Audience::where('tag_id', $tag->id)->get()->count();
                                ?>
                                <tr>
                                    <td><?php echo e($tag->tag_name); ?></td>
                                    <td><?php echo e(date('M d, Y', strtotime($tag->created_at))); ?></td>
                                    <td><?php echo e($tag->contacts->count()); ?></td>
                                    <td style="display: flex;">
                                        <a href="<?php echo e(route('tags.show', $tag->id)); ?>" class="btn btn-success btn-sm mr-1"><i
                                                class="fa fa-pencil"></i></a>
                                        <form action="<?php echo e(route('tags.destroy', $tag->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                                        </form>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/client/tags/index.blade.php ENDPATH**/ ?>