<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Overview
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            <?php echo e($client->name); ?>

                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <a href="<?php echo e(url('/admin')); ?>" class="btn btn-primary lift">
                            Back
                        </a>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->

    <!-- CARDS -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-lg-6 col-xl">

              <!-- Card -->
              <div class="card">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col">

                      <!-- Title -->
                      <h6 class="text-uppercase text-muted mb-2">
                        Total SMS
                      </h6>

                      <!-- Heading -->
                      <span class="h2 mb-0">
                        <?php echo e($sms); ?>

                      </span>


                    </div>
                    <div class="col-auto">

                      <!-- Icon -->
                      <span class="h2 fe fe-message-square text-muted mb-0"></span>

                    </div>
                  </div> <!-- / .row -->
                </div>
              </div>

            </div>
            <div class="col-12 col-lg-6 col-xl">

              <!-- Card -->
              <div class="card">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col">

                      <!-- Title -->
                      <h6 class="text-uppercase text-muted mb-2">
                        Sent SMS
                      </h6>

                      <!-- Heading -->
                      <span class="h2 mb-0">
                        <?php echo e($sms); ?>

                      </span>

                    </div>
                    <div class="col-auto">

                      <!-- Icon -->
                      <span class="h2 fe fe-send text-muted mb-0"></span>

                    </div>
                  </div> <!-- / .row -->
                </div>
              </div>

            </div>
            <div class="col-12 col-lg-6 col-xl">

              <!-- Card -->
              <div class="card">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col">

                      <!-- Title -->
                      <h6 class="text-uppercase text-muted mb-2">
                       Total Amount
                      </h6>

                      <div class="row align-items-center no-gutters">
                        <div class="col-auto">

                          <!-- Heading -->
                          <span class="h2 mr-2 mb-0">
                            KES. <?php echo e(number_format($total,2)); ?>

                          </span>

                        </div>
                        <div class="col">



                        </div>
                      </div> <!-- / .row -->
                    </div>
                    <div class="col-auto">

                      <!-- Icon -->
                      <span class="h2 fe fe-clipboard text-muted mb-0"></span>

                    </div>
                  </div> <!-- / .row -->
                </div>
              </div>

            </div>
            <div class="col-12 col-lg-6 col-xl">

              <!-- Card -->
              <div class="card">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col">

                      <!-- Title -->
                      <h6 class="text-uppercase text-muted mb-2">
                        Balance
                      </h6>

                      <!-- Heading -->
                      <span class="h2 mb-0">
                          <?php if($client->provider === 'at'): ?>
                          <?php echo e($balance); ?>

                          <?php else: ?>
                             KES. <?php echo e($balance); ?>

                          <?php endif; ?>

                      </span>

                    </div>
                    <div class="col-auto">

                       <!-- Icon -->
                       <span class="h2 fe fe-credit-card text-muted mb-0"></span>

                    </div>
                  </div> <!-- / .row -->
                </div>
              </div>

            </div>
          </div> <!-- / .row -->


        <div class="row">
            <div class="col-12">

                <!-- Goals -->
                <div class="card">
                    <div class="card-header">
                        <div class="row align-items-center">
                            <div class="col">

                                <!-- Title -->
                                <h4 class="card-header-title">
                                    Payment History
                                </h4>

                            </div>
                            <div class="col-auto">

                                <!-- Button -->
                                

                            </div>
                        </div> <!-- / .row -->
                    </div>
                    <div class="table-responsive mb-0 p-4"
                        data-list="{&quot;valueNames&quot;: [&quot;goal-project&quot;, &quot;goal-status&quot;, &quot;goal-progress&quot;, &quot;goal-date&quot;]}">
                        <table class="table table-sm table-nowrap table-hover card-table">
                            <thead>
                              <tr>
                                <th>
                                    Transaction ID
                                </th>
                                <th>
                                    Transaction Amount
                                </th>
                                <th>
                                    Transaction Date
                                </th>
                                <th>
                                    SMS Awarded
                                </th>
                                <th>
                                   Paid By
                                </th>
                              </tr>
                            </thead>
                            <tbody class="list">
                               <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                <td><?php echo e($pay->mpesa_receipt); ?></td>
                                <td>KES. <?php echo e(number_format($pay->amount,2)); ?></td>
                                <td><?php echo e(date('M d, Y', strtotime($pay->created_at))); ?></td>
                                <td><?php echo e($pay->amount); ?> SMS</td>
                                <td><?php echo e($pay->phone); ?></td>
                            </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                          </table>
                    </div>
                </div>

            </div>
        </div> <!-- / .row -->
        <div class="row">
            <div class="col-12 col-xl-12">
                 <div class="card">
                     <div class="card-header">Contacts</div>
                     <div class="card-body">
                         <table class="table table-sm">
                             <thead>
                                 <th>#</th>
                                 <th>Name</th>
                                 <th>Phone</th>
                                 <th>Email</th>
                             </thead>
                             <tbody>
                                 <?php ($count = 1); ?>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($count++); ?></td>
                                    <td><?php echo e($contact->name); ?></td>
                                    <td><?php echo e($contact->phone); ?></td>
                                    <td><?php echo e($contact->email); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             </tbody>
                         </table>
                     </div>
                 </div>
            </div>

        </div> <!-- / .row -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_provider\resources\views/admin/details.blade.php ENDPATH**/ ?>