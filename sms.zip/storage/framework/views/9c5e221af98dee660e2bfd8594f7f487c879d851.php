<?php $__env->startSection('content'); ?>
<div class="header">
    <div class="container-fluid">

      <!-- Body -->
      <div class="header-body">
        <div class="row align-items-end">
          <div class="col">

            <!-- Pretitle -->
            <h6 class="header-pretitle">
               Contacts
            </h6>

            <!-- Title -->
            <h1 class="header-title">
              Contact
            </h1>

          </div>
          <div class="col-auto">


            <a href="<?php echo e(route('contacts.create')); ?>" class="btn btn-primary lift">
              Add Contact
            </a>

          </div>
        </div> <!-- / .row -->
      </div> <!-- / .header-body -->

    </div>
  </div> <!-- / .header -->

  <div class="page-body py-4 container-fluid ">
    <div class="card">
      <div class="card-header">
        <h2 class="card-title">
          Contact List
        </h2>
      </div>
      <div class="card-body">
        <table class="table table-sm table-stripped contacts">
          <thead>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Tags</th>
            <th>ACtion</th>
          </thead>
          <tbody>

           <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
            <td><?php echo e($contact->name); ?></td>
            <td><?php echo e($contact->email); ?></td>
            <td><?php echo e("0".substr($contact->phone,4)); ?></td>
            <td>
                <?php $__currentLoopData = $contact->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-group" role="group">
                        <a href="" class="btn btn-success btn-sm"><?php echo e($tag->tag_name); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style="display: flex;">
                <a href="<?php echo e(route('contacts.show',$contact->id)); ?>" class="btn btn-success btn-sm mr-1"><i class="fa fa-pencil"></i></a>
                <form action="<?php echo e(route('contacts.destroy', $contact->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                </form>
            </td>
        </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </tbody>
        </table>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/client/contacts/index.blade.php ENDPATH**/ ?>