<?php $__env->startSection('content'); ?>
        <!-- HEADER -->
        <div class="header">
            <div class="container-fluid">

              <!-- Body -->
              <div class="header-body">
                <div class="row align-items-end">
                  <div class="col">

                    <!-- Pretitle -->
                    <h6 class="header-pretitle">
                      SMS
                    </h6>

                    <!-- Title -->
                    <h1 class="header-title">
                      Send SMS
                    </h1>

                  </div>
                  <div class="col-auto">


                    

                  </div>
                </div> <!-- / .row -->
              </div> <!-- / .header-body -->

            </div>
          </div> <!-- / .header -->
         <div class="container-fluid">
              <div class="card">
                  <div class="card-header">
                      <h2>Send SMS</h2>
                  </div>
                  <div class="card-body">
                      <?php if(session('message')): ?>
                          <div class="alert alert-success">
                              <a href="#" data-dismiss="alert" class="close">&times;</a>
                              <p><?php echo e(session('message')); ?></p>
                          </div>
                      <?php endif; ?>
                      <form action="<?php echo e(route('sms.store')); ?>" method="POST">
                          <?php echo csrf_field(); ?>
                          <div class="form-group">
                              <label for="">From:</label>
                              <select name="from" id="" class="form-control form-control-sm">
                                  <option value="" selected disabled>Select</option>
                                  <?php if(auth()->user()->provider === 'at'): ?>
                                  <option value="">Africa's Talking</option>
                                  <?php else: ?>
                                  <option value="">Mobitech</option>
                                  <?php endif; ?>
                                  
                              </select>
                          </div>
                          <div class="form-group">
                              <label for="">To:</label>
                              <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-body">

                                            <ul class="nav nav-tabs nav-tabs-solid">
                                                <li class="nav-item"><a class="nav-link active" href="#solid-tab1" data-toggle="tab">Contacts</a></li>
                                                <li class="nav-item"><a class="nav-link" href="#solid-tab2" data-toggle="tab">Tags</a></li>
                                                <li class="nav-item"><a class="nav-link" href="#solid-tab3" data-toggle="tab">Number</a></li>
                                            </ul>
                                            <div class="tab-content">
                                                <div class="tab-pane show active p-4" id="solid-tab1">
                                                    <table class="table table-sm">
                                                        <thead>
                                                            <th>
                                                                <input type="checkbox" id="checkAll"> Select All
                                                            </th>
                                                            <th>Username</th>
                                                            <th>Email</th>
                                                            <th>Mobile</th>
                                                        </thead>
                                                        <tbody>
                                                            <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                             <td>
                                                                 <input type="checkbox" class="checkbox checkitem" name="mobile[]" value="<?php echo e($contact->phone); ?>">
                                                             </td>
                                                             <td><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></td>
                                                             <td><?php echo e($contact->email); ?></td>
                                                             <td><?php echo e($contact->phone); ?></td>
                                                            </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="tab-pane p-4" id="solid-tab2">
                                                    <select name="tag" id="" class="form-control form-control-sm">
                                                        <option value="" disabled selected>Select</option>
                                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag_name); ?> > <?php echo e($tag->contacts->count()); ?> Contacts</option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="tab-pane p-4" id="solid-tab3">
                                                    <input type="number" name="contact" class="form-control form-control-sm" placeholder="i.e 0743160178">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if(session('notice')): ?>
                                   <p class="text-danger"><?php echo e(session('notice')); ?></p>
                                <?php endif; ?>

                          </div>
                          <div class="form-group">
                              <label for="">Message:</label>
                              <textarea name="message" class="form-control" id="" cols="30" rows="6"></textarea>
                              <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                  <p class="text-danger"><?php echo e($message); ?></p>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                          </div>
                          <div class="form-group">
                              <button type="submit" class="btn btn-primary pull-right"><i class="fe fe-send"></i> Send</button>
                          </div>
                      </form>
                  </div>
              </div>
         </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tedd/public_html/sms/resources/views/client/sms/index.blade.php ENDPATH**/ ?>