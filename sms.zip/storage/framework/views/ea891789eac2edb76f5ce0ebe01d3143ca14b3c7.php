<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Clients
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            Clients
                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary lift">
                          Add Client
                        </a>

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->
    <div class="container-fluid">

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Clients</h2>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-sm table-hover table-nowrap card-table">
                    <thead>
                        <th>Client Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Service Privider</th>
                        <th>Created On</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                       <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                        <td><?php echo e($client->name); ?></td>
                        <td><?php echo e($client->email); ?></td>
                        <td><?php echo e($client->primary_contact); ?></td>
                        <td>
                            <?php echo e($client->provider === 'at' ? 'Africas Talking' : 'Mobi Technologies'); ?>

                        </td>
                        <td><?php echo e(date('M d, Y', strtotime($client->created_at))); ?></td>
                        
                        <td>
                            <a href="<?php echo e(route('clients.show', $client->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-pencil"></i></a>
                            <a href="" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms\resources\views/admin/clients/index.blade.php ENDPATH**/ ?>