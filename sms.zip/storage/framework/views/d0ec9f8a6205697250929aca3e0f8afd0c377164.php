<?php $__env->startSection('content'); ?>
    <!-- HEADER -->
    <div class="header">
        <div class="container-fluid">

            <!-- Body -->
            <div class="header-body">
                <div class="row align-items-end">
                    <div class="col">

                        <!-- Pretitle -->
                        <h6 class="header-pretitle">
                            Reports
                        </h6>

                        <!-- Title -->
                        <h1 class="header-title">
                            Reports
                        </h1>

                    </div>
                    <div class="col-auto">

                        <!-- Button -->
                        

                    </div>
                </div> <!-- / .row -->
            </div> <!-- / .header-body -->

        </div>
    </div> <!-- / .header -->
    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Reports</h2>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <thead>
                        <th>Month</th>
                        <th>Total SMS Send</th>
                        <th>Total Cost</th>
                        

                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>March, 2021</td>
                            <td><?php echo e($item->total); ?></td>
                            <td>KES <?php echo e($item->total); ?>.00</td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sms_system\resources\views/client/reports/index.blade.php ENDPATH**/ ?>