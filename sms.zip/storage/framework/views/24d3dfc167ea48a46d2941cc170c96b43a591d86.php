    <script src="<?php echo e(asset('libs/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/@shopify/draggable/lib/es5/draggable.bundle.legacy.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/autosize/dist/autosize.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/dropzone/dist/min/dropzone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/flatpickr/dist/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/highlightjs/highlight.pack.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/jquery-mask-plugin/dist/jquery.mask.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/list.js/dist/list.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/quill/dist/quill.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/select2/dist/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/chart.js/Chart.extension.js')); ?>"></script>

    <!-- Map -->
    <script src='https://api.mapbox.com/mapbox-gl-js/v0.53.0/mapbox-gl.js'></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"  referrerpolicy="no-referrer"></script>
    <!-- Theme JS -->
    <script src="<?php echo e(asset('js/theme.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dashkit.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    
</body>

</html>

<?php /**PATH C:\xampp\htdocs\sms\resources\views/layouts/footer.blade.php ENDPATH**/ ?>